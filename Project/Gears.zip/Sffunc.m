function [Sf] = Sffunc()
%Sf is factor of safety
Sf = ;
end