function [value] = Stfunc (St_value)
value = St_value;
%see bracketed values in tables 14-3 and 14-4 on pages 740 and 741 for
%metric values. Table 14-3 is for steel.
end