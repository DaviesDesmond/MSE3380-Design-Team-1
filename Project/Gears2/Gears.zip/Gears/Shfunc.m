function [Sh] = Shfunc()
%Sh = wear factor of safety.
Sh = ;
end