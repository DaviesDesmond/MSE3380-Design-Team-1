function [value] = Hfunc(Hbp,Hbg)
H