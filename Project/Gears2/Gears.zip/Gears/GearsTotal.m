% descriptions of input variables
% d: diameter - inputed
% N: number of teeth - inputed
% H: input power - inputed
% F: Facewidth - inputed
% RPM: revolutions per minute - inputed
% Yn_lookup: use FIGURE 14-14 pg. 755 - input
% b: facewidth = F
% d diameter = D
% J_lookup: use FIGURE 14-6, pg 745 Shigely - imputed
% N_cyc: Number of cycles - inputed
% Hb: Brinell Hardness - need to find
% Grade: Metalurgical Grade - need to find
%  mg: speed ratio - input
G1_D=;
G1_N=;
G1_H=;
G1_F=;
G1_RPM=;
G1_Yn_LOOKUP=;
G1_J_LOOKUP=;
G1_b=G1_F;
G1_N_cyc=;
G1_mg=;

G2_D=;
G2_N=;
G2_H=;
G2_F=;
G2_RPM=;
G2_Yn_LOOKUP=;
G2_J_LOOKUP=;
G2_b=G1_F;
G2_N_cyc=;
G2_mg=;

P1_D=;
P1_N=;
P1_H=;
P1_F=;
P1_RPM=;
P1_Yn_LOOKUP=;
P1_J_LOOKUP=;
P1_b=G1_F;
P1_N_cyc=;
P1_mg=;

P2_D=;
P2_N=;
P2_H=;
P2_F=;
P2_RPM=;
P2_Yn_LOOKUP=;
P2_J_LOOKUP=;
P2_b=G1_F;
P2_N_cyc=;
P2_mg=;


Hb=;
G_grade=;
P_grade=;


[G1_BS,G1_BS_FOS,G1_CS,G1_CS_FOS] = gear(G1_D,G1_N,G1_H,G1_F,G1_RPM,G1_Yn_LOOKUP,12,9,1,3,3,0,2,0,G1_J_LOOKUP,Hb,Hb,0,G1_N_cyc,0.9,Hb,G_grade,0,1,1,G1_mg,0.2530727,1);
[P1_BS,P1_BS_FOS,P1_CS,P1_CS_FOS] = gear(P1_D,P1_N,P1_H,P1_F,P1_RPM,P1_Yn_LOOKUP,12,9,1,3,3,0,2,0,P1_J_LOOKUP,Hb,Hb,0,P1_N_cyc,0.9,Hb,P_grade,0,1,1,P1_mg,0.2530727,1);
[G2_BS,G2_BS_FOS,G2_CS,G2_CS_FOS] = gear(G2_D,G2_N,G2_H,G2_F,G2_RPM,G2_Yn_LOOKUP,12,9,1,3,3,0,2,0,G2_J_LOOKUP,Hb,Hb,0,G2_N_cyc,0.9,Hb,G_grade,0,1,1,G2_mg,0.2530727,1);
[P2_BS,P2_BS_FOS,P2_CS,P2_CS_FOS] = gear(P2_D,P2_N,P2_H,P2_F,P2_RPM,P2_Yn_LOOKUP,12,9,1,3,3,0,2,0,P2_J_LOOKUP,Hb,Hb,0,P2_N_cyc,0.9,Hb,P_grade,0,1,1,P2_mg,0.2530727,1);
