function[mg] = mgfunc()
mg = 5; %change based on actual gear ratio.
%Remember: Gear over pinion/driven over driving.
end