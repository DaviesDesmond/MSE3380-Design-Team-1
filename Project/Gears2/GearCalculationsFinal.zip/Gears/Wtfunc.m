function [Wt] = Wtfunc (H,V)
Wt = H/V; %Gives units in Newtons if passing SI units.
end