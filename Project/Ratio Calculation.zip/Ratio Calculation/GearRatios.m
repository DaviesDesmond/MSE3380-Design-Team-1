Pitch24Gear = [12 15 16 18 21 24 30 36 42 48 60 72 96 120 144 0 0 0 0 0 0]
Pitch20Gear = [11 12 13 14 15 16 18 20 22 24 25 28 30 32 35 36 40 48 50 60 64]

N15P24 = GearRatioW15Set(Pitch24Gear);
N15P20 = GearRatioW15Set(Pitch20Gear);

P24Square = GearRatioIndSet(Pitch24Gear);
P20Square = GearRatioIndSet(Pitch20Gear);

Options1 = OptionMaker(N15P24,P24Square);
Options2 = OptionMaker(N15P24,P20Square);
Options3 = OptionMaker(N15P20,P24Square);
Options4 = OptionMaker(N15P20,P20Square);

Options5 = OptionMakerSquare(P24Square,P20Square,21);
Options6 = OptionMakerSquare(P24Square,P24Square,21);
Options7 = OptionMakerSquare(P20Square,P20Square,21);

GoodOP1 = Options1 >= 0.0349 & Options1<= 0.0351; % Dependent on GearRatio
GoodOP2 = Options2 >= 0.0349 & Options2<= 0.0351;
GoodOP3 = Options3 >= 0.0349 & Options3<= 0.0351;
GoodOP4 = Options4 >= 0.0349 & Options4<= 0.0351;

GoodOP5 = Options5>=0.0029565870 & Options5 <=0.029565871;
GoodOP6 = Options6>=0.0029565870 & Options6 <=0.029565871;
GoodOP7 = Options7>=0.0029565870 & Options7 <=0.029565871;


OP1 = find(GoodOP1 ==1);
OP2 = find(GoodOP2 ==1);
OP3 = find(GoodOP3 ==1);
OP4 = find(GoodOP4 ==1);
OP5 = find(GoodOP5 ==1);
OP6 = find(GoodOP6 ==1);
OP7 = find(GoodOP7 ==1);

%New because we have an option
OPTIONOMG = Options2(OP2);
