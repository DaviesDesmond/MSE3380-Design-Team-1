
Pitch20Gear = [11 12 13 14 15 16 18 20 22 24 25 28 30 32 35 36 40 48 50 60 64]

P20Square = GearRatioIndSet(Pitch20Gear);

Options7 = OptionMakerSquare(P20Square,P20Square,21); %Options7 is 4D 21^4 Matrix

GoodOP7 = Options7>=0.0029565870 & Options7 <=0.029565871;

OP7 = find(GoodOP7 ==1); %index in Options7

Value = Options7(OP7);


