Pitch32Gear = [16 18 20 22 24 26 28 30 32 40 48 56 64 80] % length 14

P32Square = GearRatioIndSet(Pitch32Gear); %function works find (length)

Options7 = OptionMakerSquare(P32Square,P32Square,14);

GoodOP7 = Options7>=0.00294 & Options7 <=0.0296;

OP7 = find(GoodOP7 ==1);

