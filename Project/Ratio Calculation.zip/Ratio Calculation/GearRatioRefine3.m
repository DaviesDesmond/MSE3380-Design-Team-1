Pitch24Gear = [12 14 15 16 18 20 21 24 30 36 42 48 60] % length 13

P24Square = GearRatioIndSet(Pitch24Gear); %function works find (length)

Options7 = OptionMakerSquare(P24Square,P24Square,13);

GoodOP7 = Options7>=0.00294 & Options7 <=0.0296;

OP7 = find(GoodOP7 ==1);