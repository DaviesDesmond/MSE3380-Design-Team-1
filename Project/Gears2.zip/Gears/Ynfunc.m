function [Yn] = Ynfunc(Yn_Input)
%See page 755 for figure 14-14 for Yn.
Yn = Yn_Input;
end
